from . import views
from django.urls import path
from .views import lista_productos

urlpatterns = [
    path("", views.BienvenidaProductos, name="BienvenidaProductos"),
]

urlpatterns = [
    path("productos/", lista_productos, name="lista_productos"),
]
