from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Producto


# Create your views here.


def Productos(request):
    return HttpResponse("<h1>Nuestra Primera vistan completado!<h1>")


def BienvenidaProductos(request):
    template = loader.get_template("index.html")
    return HttpResponse(template.render())


def lista_productos(request):
    productos = Producto.objects.all()
    return render(request, "lista_productos.html", {"productos": productos})
